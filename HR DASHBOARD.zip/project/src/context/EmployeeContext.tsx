import React, { createContext, useContext, useState, useEffect } from 'react';
import { Employee } from '../types/employee';

interface EmployeeContextType {
  employees: Employee[];
  filteredEmployees: Employee[];
  loading: boolean;
  error: string | null;
  searchTerm: string;
  selectedDepartments: string[];
  selectedRatings: number[];
  setSearchTerm: (term: string) => void;
  setSelectedDepartments: (departments: string[]) => void;
  setSelectedRatings: (ratings: number[]) => void;
  getEmployeeById: (id: number) => Employee | undefined;
  getDepartments: () => string[];
}

const EmployeeContext = createContext<EmployeeContextType | undefined>(undefined);

export function EmployeeProvider({ children }: { children: React.ReactNode }) {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [filteredEmployees, setFilteredEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDepartments, setSelectedDepartments] = useState<string[]>([]);
  const [selectedRatings, setSelectedRatings] = useState<number[]>([]);

  // Fetch employees from API
  useEffect(() => {
    const fetchEmployees = async () => {
      try {
        setLoading(true);
        const response = await fetch('https://dummyjson.com/users?limit=20');
        
        if (!response.ok) {
          throw new Error('Failed to fetch employees');
        }
        
        const data = await response.json();
        
        // Transform the data to add department and performance rating
        const departments = ['Engineering', 'Marketing', 'HR', 'Finance', 'Sales', 'Product', 'Design'];
        
        const transformedEmployees: Employee[] = data.users.map((user: any) => {
          // Generate random department
          const department = departments[Math.floor(Math.random() * departments.length)];
          
          // Generate random performance rating (1-5)
          const performanceRating = Math.floor(Math.random() * 5) + 1;
          
          return {
            ...user,
            department,
            performanceRating,
            performanceHistory: generatePerformanceHistory(),
            projects: generateProjects(),
            feedback: generateFeedback(),
          };
        });
        
        setEmployees(transformedEmployees);
        setFilteredEmployees(transformedEmployees);
        setLoading(false);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An error occurred');
        setLoading(false);
      }
    };
    
    fetchEmployees();
  }, []);

  // Filter employees based on search term and filters
  useEffect(() => {
    let results = employees;
    
    // Apply search filter
    if (searchTerm) {
      const lowercaseTerm = searchTerm.toLowerCase();
      results = results.filter(
        employee => 
          employee.firstName.toLowerCase().includes(lowercaseTerm) ||
          employee.lastName.toLowerCase().includes(lowercaseTerm) ||
          employee.email.toLowerCase().includes(lowercaseTerm) ||
          (employee.department && employee.department.toLowerCase().includes(lowercaseTerm))
      );
    }
    
    // Apply department filter
    if (selectedDepartments.length > 0) {
      results = results.filter(employee => 
        selectedDepartments.includes(employee.department)
      );
    }
    
    // Apply rating filter
    if (selectedRatings.length > 0) {
      results = results.filter(employee => 
        selectedRatings.includes(employee.performanceRating)
      );
    }
    
    setFilteredEmployees(results);
  }, [employees, searchTerm, selectedDepartments, selectedRatings]);

  // Helper to get employee by ID
  const getEmployeeById = (id: number) => {
    return employees.find(employee => employee.id === id);
  };

  // Helper to get unique departments
  const getDepartments = () => {
    const departments = employees.map(employee => employee.department);
    return [...new Set(departments)];
  };

  // Helper functions for generating mock data
  function generatePerformanceHistory() {
    const history = [];
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    
    for (let i = 0; i < 5; i++) {
      const month = months[Math.floor(Math.random() * months.length)];
      const year = 2023 - Math.floor(i / 12);
      const rating = Math.floor(Math.random() * 5) + 1;
      
      history.push({
        date: `${month} ${year}`,
        rating,
        feedback: getRandomFeedback(rating),
      });
    }
    
    return history;
  }
  
  function generateProjects() {
    const projects = [];
    const projectNames = [
      'Website Redesign', 'Mobile App Development', 'Marketing Campaign', 
      'Financial Analysis', 'Product Launch', 'Customer Research', 
      'Data Migration', 'API Integration'
    ];
    
    const numProjects = Math.floor(Math.random() * 3) + 1;
    
    for (let i = 0; i < numProjects; i++) {
      projects.push({
        name: projectNames[Math.floor(Math.random() * projectNames.length)],
        role: ['Lead', 'Contributor', 'Manager'][Math.floor(Math.random() * 3)],
        status: ['Completed', 'In Progress', 'Planned'][Math.floor(Math.random() * 3)],
        completionPercentage: Math.floor(Math.random() * 101),
      });
    }
    
    return projects;
  }
  
  function generateFeedback() {
    const feedback = [];
    const reviewers = ['John Smith', 'Jane Doe', 'Michael Johnson', 'Emily Davis', 'Robert Wilson'];
    
    const numFeedbacks = Math.floor(Math.random() * 3) + 1;
    
    for (let i = 0; i < numFeedbacks; i++) {
      feedback.push({
        reviewer: reviewers[Math.floor(Math.random() * reviewers.length)],
        date: new Date(Date.now() - Math.floor(Math.random() * 90) * 24 * 60 * 60 * 1000).toLocaleDateString(),
        rating: Math.floor(Math.random() * 5) + 1,
        comment: getRandomFeedback(Math.floor(Math.random() * 5) + 1),
      });
    }
    
    return feedback;
  }
  
  function getRandomFeedback(rating: number) {
    const positiveFeedback = [
      'Consistently delivers high-quality work.',
      'Excellent team player with strong communication skills.',
      'Takes initiative and goes above and beyond.',
      'Highly skilled and knowledgeable in their domain.',
      'Great problem solver with creative solutions.',
    ];
    
    const neutralFeedback = [
      'Meets expectations and delivers work on time.',
      'Works well with the team but could improve communication.',
      'Completes assigned tasks adequately.',
      'Has necessary skills but could benefit from additional training.',
      'Reliable team member who follows processes.',
    ];
    
    const negativeFeedback = [
      'Struggles to meet deadlines consistently.',
      'Communication skills need improvement.',
      'Work quality is inconsistent and requires review.',
      'Needs more technical training to perform effectively.',
      'Has difficulty adapting to changing requirements.',
    ];
    
    if (rating >= 4) {
      return positiveFeedback[Math.floor(Math.random() * positiveFeedback.length)];
    } else if (rating >= 2) {
      return neutralFeedback[Math.floor(Math.random() * neutralFeedback.length)];
    } else {
      return negativeFeedback[Math.floor(Math.random() * negativeFeedback.length)];
    }
  }

  return (
    <EmployeeContext.Provider 
      value={{
        employees,
        filteredEmployees,
        loading,
        error,
        searchTerm,
        selectedDepartments,
        selectedRatings,
        setSearchTerm,
        setSelectedDepartments,
        setSelectedRatings,
        getEmployeeById,
        getDepartments,
      }}
    >
      {children}
    </EmployeeContext.Provider>
  );
}

export function useEmployees() {
  const context = useContext(EmployeeContext);
  if (context === undefined) {
    throw new Error('useEmployees must be used within an EmployeeProvider');
  }
  return context;
}