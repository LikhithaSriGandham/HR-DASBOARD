import React, { createContext, useContext, useState, useEffect } from 'react';
import { Employee } from '../types/employee';

interface BookmarkContextType {
  bookmarkedEmployees: number[];
  addBookmark: (employeeId: number) => void;
  removeBookmark: (employeeId: number) => void;
  isBookmarked: (employeeId: number) => boolean;
}

const BookmarkContext = createContext<BookmarkContextType | undefined>(undefined);

export function BookmarkProvider({ children }: { children: React.ReactNode }) {
  // Initialize bookmarks from localStorage
  const [bookmarkedEmployees, setBookmarkedEmployees] = useState<number[]>(() => {
    const savedBookmarks = localStorage.getItem('bookmarkedEmployees');
    return savedBookmarks ? JSON.parse(savedBookmarks) : [];
  });

  // Update localStorage when bookmarks change
  useEffect(() => {
    localStorage.setItem('bookmarkedEmployees', JSON.stringify(bookmarkedEmployees));
  }, [bookmarkedEmployees]);

  // Add employee to bookmarks
  const addBookmark = (employeeId: number) => {
    if (!bookmarkedEmployees.includes(employeeId)) {
      setBookmarkedEmployees([...bookmarkedEmployees, employeeId]);
    }
  };

  // Remove employee from bookmarks
  const removeBookmark = (employeeId: number) => {
    setBookmarkedEmployees(bookmarkedEmployees.filter(id => id !== employeeId));
  };

  // Check if employee is bookmarked
  const isBookmarked = (employeeId: number) => {
    return bookmarkedEmployees.includes(employeeId);
  };

  return (
    <BookmarkContext.Provider 
      value={{
        bookmarkedEmployees,
        addBookmark,
        removeBookmark,
        isBookmarked,
      }}
    >
      {children}
    </BookmarkContext.Provider>
  );
}

export function useBookmarks() {
  const context = useContext(BookmarkContext);
  if (context === undefined) {
    throw new Error('useBookmarks must be used within a BookmarkProvider');
  }
  return context;
}