import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Eye, Bookmark, BookmarkCheck, Award } from 'lucide-react';
import { useBookmarks } from '../../context/BookmarkContext';
import { Employee } from '../../types/employee';
import RatingStars from './RatingStars';

interface EmployeeCardProps {
  employee: Employee;
}

const EmployeeCard: React.FC<EmployeeCardProps> = ({ employee }) => {
  const navigate = useNavigate();
  const { isBookmarked, addBookmark, removeBookmark } = useBookmarks();
  const bookmarked = isBookmarked(employee.id);

  const handleView = () => {
    navigate(`/employee/${employee.id}`);
  };

  const handleBookmark = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (bookmarked) {
      removeBookmark(employee.id);
    } else {
      addBookmark(employee.id);
    }
  };

  const handlePromote = (e: React.MouseEvent) => {
    e.stopPropagation();
    alert(`${employee.firstName} ${employee.lastName} has been promoted!`);
  };

  // Get department color
  const getDepartmentColor = (department: string) => {
    const colors: Record<string, string> = {
      'Engineering': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
      'Marketing': 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
      'HR': 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200',
      'Finance': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
      'Sales': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
      'Product': 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200',
      'Design': 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
    };

    return colors[department] || 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200';
  };

  return (
    <div 
      className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg border border-gray-200 dark:border-gray-700"
    >
      <div className="p-5">
        <div className="flex items-start justify-between">
          <div className="flex items-center">
            <img 
              src={employee.image} 
              alt={`${employee.firstName} ${employee.lastName}`}
              className="w-12 h-12 rounded-full object-cover"
            />
            <div className="ml-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                {employee.firstName} {employee.lastName}
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">{employee.email}</p>
            </div>
          </div>
          <span className={`text-xs font-medium px-2.5 py-0.5 rounded-full ${getDepartmentColor(employee.department)}`}>
            {employee.department}
          </span>
        </div>

        <div className="mt-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <span className="text-sm text-gray-700 dark:text-gray-300 mr-2">Performance:</span>
              <RatingStars rating={employee.performanceRating} />
            </div>
            <span className="text-sm text-gray-700 dark:text-gray-300">Age: {employee.age}</span>
          </div>
        </div>

        <div className="mt-5 flex justify-between">
          <button
            onClick={handleView}
            className="flex items-center justify-center px-3 py-1.5 rounded-md bg-indigo-50 text-indigo-600 hover:bg-indigo-100 dark:bg-indigo-900/30 dark:text-indigo-400 dark:hover:bg-indigo-800/50 transition-colors"
          >
            <Eye size={16} className="mr-1" />
            <span>View</span>
          </button>
          
          <button
            onClick={handleBookmark}
            className={`flex items-center justify-center px-3 py-1.5 rounded-md transition-colors ${
              bookmarked 
                ? 'bg-amber-50 text-amber-600 hover:bg-amber-100 dark:bg-amber-900/30 dark:text-amber-400 dark:hover:bg-amber-800/50' 
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-400 dark:hover:bg-gray-600'
            }`}
          >
            {bookmarked ? (
              <>
                <BookmarkCheck size={16} className="mr-1" />
                <span>Saved</span>
              </>
            ) : (
              <>
                <Bookmark size={16} className="mr-1" />
                <span>Bookmark</span>
              </>
            )}
          </button>
          
          <button
            onClick={handlePromote}
            className="flex items-center justify-center px-3 py-1.5 rounded-md bg-green-50 text-green-600 hover:bg-green-100 dark:bg-green-900/30 dark:text-green-400 dark:hover:bg-green-800/50 transition-colors"
          >
            <Award size={16} className="mr-1" />
            <span>Promote</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default EmployeeCard;