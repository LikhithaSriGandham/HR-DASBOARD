import React from 'react';
import { Star } from 'lucide-react';

interface RatingStarsProps {
  rating: number;
  size?: 'sm' | 'md' | 'lg';
}

const RatingStars: React.FC<RatingStarsProps> = ({ rating, size = 'md' }) => {
  const totalStars = 5;
  
  // Determine star size based on prop
  const getStarSize = () => {
    switch (size) {
      case 'sm':
        return 14;
      case 'lg':
        return 22;
      case 'md':
      default:
        return 18;
    }
  };

  // Determine star colors based on rating
  const getStarColor = (starPosition: number) => {
    if (starPosition <= rating) {
      // Determine color based on rating range
      if (rating >= 4) {
        return 'text-green-500 dark:text-green-400 fill-green-500 dark:fill-green-400';
      } else if (rating >= 3) {
        return 'text-blue-500 dark:text-blue-400 fill-blue-500 dark:fill-blue-400';
      } else if (rating >= 2) {
        return 'text-amber-500 dark:text-amber-400 fill-amber-500 dark:fill-amber-400';
      } else {
        return 'text-red-500 dark:text-red-400 fill-red-500 dark:fill-red-400';
      }
    }
    
    return 'text-gray-300 dark:text-gray-600';
  };

  const starSize = getStarSize();

  return (
    <div className="flex">
      {[...Array(totalStars)].map((_, index) => (
        <Star
          key={index}
          size={starSize}
          className={`${getStarColor(index + 1)} ${
            index + 1 <= rating ? 'fill-current' : ''
          } transition-colors duration-200`}
        />
      ))}
    </div>
  );
};

export default RatingStars;