import React, { useState, useRef, useEffect } from 'react';
import { ChevronDown, X } from 'lucide-react';
import { useEmployees } from '../../context/EmployeeContext';

interface FilterOption {
  label: string;
  value: string | number;
}

interface FilterDropdownProps {
  type: 'department' | 'rating';
  options: FilterOption[];
  label: string;
}

const FilterDropdown: React.FC<FilterDropdownProps> = ({ type, options, label }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  
  const { 
    selectedDepartments, 
    selectedRatings, 
    setSelectedDepartments, 
    setSelectedRatings 
  } = useEmployees();

  const selected = type === 'department' ? selectedDepartments : selectedRatings;

  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };

  const handleOptionClick = (value: string | number) => {
    if (type === 'department') {
      const stringValue = value as string;
      if (selectedDepartments.includes(stringValue)) {
        setSelectedDepartments(selectedDepartments.filter(item => item !== stringValue));
      } else {
        setSelectedDepartments([...selectedDepartments, stringValue]);
      }
    } else {
      const numValue = value as number;
      if (selectedRatings.includes(numValue)) {
        setSelectedRatings(selectedRatings.filter(item => item !== numValue));
      } else {
        setSelectedRatings([...selectedRatings, numValue]);
      }
    }
  };

  const clearFilters = () => {
    if (type === 'department') {
      setSelectedDepartments([]);
    } else {
      setSelectedRatings([]);
    }
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div className="relative" ref={dropdownRef}>
      <button 
        onClick={toggleDropdown}
        className="flex items-center justify-between px-4 py-2 text-sm bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg shadow-sm hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors min-w-[160px]"
      >
        <div className="flex items-center">
          <span className="text-gray-700 dark:text-gray-200">
            {selected.length > 0 ? `${label} (${selected.length})` : label}
          </span>
        </div>
        <ChevronDown size={16} className="ml-2 text-gray-400" />
      </button>

      {isOpen && (
        <div className="absolute z-10 mt-1 w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg py-1 max-h-60 overflow-auto">
          <div className="px-3 py-2 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
            <span className="font-medium text-sm text-gray-700 dark:text-gray-300">
              {label}
            </span>
            {selected.length > 0 && (
              <button 
                onClick={clearFilters}
                className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline flex items-center"
              >
                <X size={12} className="mr-1" />
                Clear
              </button>
            )}
          </div>
          
          <div className="py-1">
            {options.map((option) => (
              <label 
                key={option.value.toString()} 
                className="flex items-center px-3 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer"
              >
                <input
                  type="checkbox"
                  checked={selected.includes(option.value)}
                  onChange={() => handleOptionClick(option.value)}
                  className="h-4 w-4 text-indigo-600 rounded border-gray-300 focus:ring-indigo-500 dark:border-gray-600 dark:bg-gray-700"
                />
                <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                  {option.label}
                </span>
              </label>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default FilterDropdown;