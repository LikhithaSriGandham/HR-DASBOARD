import React from 'react';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { useTheme } from '../../context/ThemeContext';
import { Employee } from '../../types/employee';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface PerformanceChartProps {
  employees: Employee[];
}

const PerformanceChart: React.FC<PerformanceChartProps> = ({ employees }) => {
  const { theme } = useTheme();
  
  // Calculate department-wise average ratings
  const calculateDepartmentPerformance = () => {
    const departmentMap: Record<string, { total: number; count: number }> = {};
    
    employees.forEach(employee => {
      if (!departmentMap[employee.department]) {
        departmentMap[employee.department] = { total: 0, count: 0 };
      }
      departmentMap[employee.department].total += employee.performanceRating;
      departmentMap[employee.department].count += 1;
    });
    
    const departments = Object.keys(departmentMap);
    const averageRatings = departments.map(dept => 
      departmentMap[dept].total / departmentMap[dept].count
    );
    
    return { departments, averageRatings };
  };
  
  const { departments, averageRatings } = calculateDepartmentPerformance();
  
  // Set chart colors based on theme
  const getChartColors = () => {
    return theme === 'dark' 
      ? {
          backgroundColor: [
            'rgba(59, 130, 246, 0.7)', // blue
            'rgba(139, 92, 246, 0.7)',  // purple
            'rgba(236, 72, 153, 0.7)',  // pink
            'rgba(34, 197, 94, 0.7)',   // green
            'rgba(250, 204, 21, 0.7)',  // yellow
            'rgba(99, 102, 241, 0.7)',  // indigo
            'rgba(239, 68, 68, 0.7)',   // red
          ],
          borderColor: [
            'rgba(59, 130, 246, 1)',
            'rgba(139, 92, 246, 1)',
            'rgba(236, 72, 153, 1)',
            'rgba(34, 197, 94, 1)',
            'rgba(250, 204, 21, 1)',
            'rgba(99, 102, 241, 1)',
            'rgba(239, 68, 68, 1)',
          ],
          color: 'rgba(255, 255, 255, 0.8)',
          gridColor: 'rgba(255, 255, 255, 0.1)',
        }
      : {
          backgroundColor: [
            'rgba(59, 130, 246, 0.5)',
            'rgba(139, 92, 246, 0.5)',
            'rgba(236, 72, 153, 0.5)',
            'rgba(34, 197, 94, 0.5)',
            'rgba(250, 204, 21, 0.5)',
            'rgba(99, 102, 241, 0.5)',
            'rgba(239, 68, 68, 0.5)',
          ],
          borderColor: [
            'rgba(59, 130, 246, 1)',
            'rgba(139, 92, 246, 1)',
            'rgba(236, 72, 153, 1)',
            'rgba(34, 197, 94, 1)',
            'rgba(250, 204, 21, 1)',
            'rgba(99, 102, 241, 1)',
            'rgba(239, 68, 68, 1)',
          ],
          color: 'rgba(0, 0, 0, 0.8)',
          gridColor: 'rgba(0, 0, 0, 0.1)',
        };
  };
  
  const chartColors = getChartColors();
  
  const data = {
    labels: departments,
    datasets: [
      {
        label: 'Average Performance Rating',
        data: averageRatings,
        backgroundColor: chartColors.backgroundColor,
        borderColor: chartColors.borderColor,
        borderWidth: 1,
      },
    ],
  };
  
  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          color: chartColors.color,
        },
      },
      title: {
        display: true,
        text: 'Department Performance Ratings',
        color: chartColors.color,
        font: {
          size: 16,
        },
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            return `Rating: ${context.parsed.y.toFixed(2)}`;
          }
        }
      }
    },
    scales: {
      x: {
        grid: {
          color: chartColors.gridColor,
        },
        ticks: {
          color: chartColors.color,
        },
      },
      y: {
        beginAtZero: true,
        max: 5,
        grid: {
          color: chartColors.gridColor,
        },
        ticks: {
          color: chartColors.color,
          callback: function(value: any) {
            return value.toFixed(1);
          }
        },
      },
    },
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md border border-gray-200 dark:border-gray-700">
      <Bar data={data} options={options} />
    </div>
  );
};

export default PerformanceChart;