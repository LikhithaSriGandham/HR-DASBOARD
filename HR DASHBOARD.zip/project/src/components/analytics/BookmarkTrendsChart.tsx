import React from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { useTheme } from '../../context/ThemeContext';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface BookmarkTrendsChartProps {
  bookmarkedCount: number;
}

const BookmarkTrendsChart: React.FC<BookmarkTrendsChartProps> = ({ bookmarkedCount }) => {
  const { theme } = useTheme();
  
  // Generate mock data for bookmark trends
  const generateMockTrendData = () => {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const currentMonth = new Date().getMonth();
    
    // Get last 6 months
    const labels = [];
    for (let i = 5; i >= 0; i--) {
      const monthIndex = (currentMonth - i + 12) % 12;
      labels.push(months[monthIndex]);
    }
    
    // Generate mock data for two trend lines
    const bookmarksData = [];
    let previousValue = Math.floor(Math.random() * 5);
    
    for (let i = 0; i < 5; i++) {
      const change = Math.floor(Math.random() * 3) - 1; // -1, 0, or 1
      previousValue = Math.max(0, previousValue + change);
      bookmarksData.push(previousValue);
    }
    
    // Use actual bookmarked count for the last value
    bookmarksData.push(bookmarkedCount);
    
    return { labels, bookmarksData };
  };
  
  const { labels, bookmarksData } = generateMockTrendData();
  
  // Set chart colors based on theme
  const getChartColors = () => {
    return theme === 'dark' 
      ? {
          backgroundColor: 'rgba(99, 102, 241, 0.2)',
          borderColor: 'rgba(99, 102, 241, 1)',
          pointBackgroundColor: 'rgba(99, 102, 241, 1)',
          color: 'rgba(255, 255, 255, 0.8)',
          gridColor: 'rgba(255, 255, 255, 0.1)',
        }
      : {
          backgroundColor: 'rgba(99, 102, 241, 0.2)',
          borderColor: 'rgba(99, 102, 241, 1)',
          pointBackgroundColor: 'rgba(99, 102, 241, 1)',
          color: 'rgba(0, 0, 0, 0.8)',
          gridColor: 'rgba(0, 0, 0, 0.1)',
        };
  };
  
  const chartColors = getChartColors();
  
  const data = {
    labels,
    datasets: [
      {
        label: 'Bookmarks',
        data: bookmarksData,
        fill: true,
        backgroundColor: chartColors.backgroundColor,
        borderColor: chartColors.borderColor,
        pointBackgroundColor: chartColors.pointBackgroundColor,
        tension: 0.3,
      },
    ],
  };
  
  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          color: chartColors.color,
        },
      },
      title: {
        display: true,
        text: 'Bookmark Trends',
        color: chartColors.color,
        font: {
          size: 16,
        },
      },
    },
    scales: {
      x: {
        grid: {
          color: chartColors.gridColor,
        },
        ticks: {
          color: chartColors.color,
        },
      },
      y: {
        beginAtZero: true,
        grid: {
          color: chartColors.gridColor,
        },
        ticks: {
          color: chartColors.color,
          stepSize: 1,
        },
      },
    },
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md border border-gray-200 dark:border-gray-700">
      <Line data={data} options={options} />
    </div>
  );
};

export default BookmarkTrendsChart;