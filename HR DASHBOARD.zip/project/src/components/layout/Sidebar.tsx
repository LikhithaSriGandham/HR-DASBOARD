import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  Bookmark, 
  PieChart, 
  Settings, 
  HelpCircle, 
  LogOut,
  Briefcase,
  ChevronRight,
  ChevronLeft,
} from 'lucide-react';

const Sidebar = () => {
  const location = useLocation();
  const [collapsed, setCollapsed] = useState(false);

  const toggleSidebar = () => {
    setCollapsed(!collapsed);
  };

  const navItems = [
    { name: 'Dashboard', path: '/', icon: <LayoutDashboard size={20} /> },
    { name: 'Bookmarks', path: '/bookmarks', icon: <Bookmark size={20} /> },
    { name: 'Analytics', path: '/analytics', icon: <PieChart size={20} /> },
  ];

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <aside 
      className={`${
        collapsed ? 'w-16' : 'w-64'
      } bg-indigo-700 text-white flex flex-col transition-all duration-300 ease-in-out h-screen`}
    >
      {/* Logo */}
      <div className="flex items-center px-4 py-5">
        <Briefcase className="h-8 w-8 text-white" />
        {!collapsed && (
          <h1 className="ml-2 text-xl font-bold">HR Dashboard</h1>
        )}
      </div>

      {/* Toggle button */}
      <button 
        onClick={toggleSidebar}
        className="absolute -right-3 top-12 bg-indigo-500 rounded-full p-1 text-white shadow-md z-10"
      >
        {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
      </button>

      {/* Navigation */}
      <nav className="flex-1 pt-5">
        <ul className="space-y-2 px-2">
          {navItems.map((item) => (
            <li key={item.path}>
              <Link
                to={item.path}
                className={`flex items-center px-4 py-3 rounded-lg transition-colors ${
                  isActive(item.path)
                    ? 'bg-indigo-800 text-white'
                    : 'text-indigo-100 hover:bg-indigo-600'
                }`}
              >
                <span className="text-xl">{item.icon}</span>
                {!collapsed && <span className="ml-3">{item.name}</span>}
              </Link>
            </li>
          ))}
        </ul>
      </nav>

      {/* Footer */}
      <div className="border-t border-indigo-600 pt-2 pb-4 px-2">
        <ul className="space-y-2">
          <li>
            <Link
              to="#"
              className="flex items-center px-4 py-3 text-indigo-100 hover:bg-indigo-600 rounded-lg transition-colors"
            >
              <Settings size={20} />
              {!collapsed && <span className="ml-3">Settings</span>}
            </Link>
          </li>
          <li>
            <Link
              to="#"
              className="flex items-center px-4 py-3 text-indigo-100 hover:bg-indigo-600 rounded-lg transition-colors"
            >
              <HelpCircle size={20} />
              {!collapsed && <span className="ml-3">Help</span>}
            </Link>
          </li>
          <li>
            <Link
              to="#"
              className="flex items-center px-4 py-3 text-indigo-100 hover:bg-indigo-600 rounded-lg transition-colors"
            >
              <LogOut size={20} />
              {!collapsed && <span className="ml-3">Logout</span>}
            </Link>
          </li>
        </ul>
      </div>
    </aside>
  );
};

export default Sidebar;