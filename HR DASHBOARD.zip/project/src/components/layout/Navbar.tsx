import React from 'react';
import { Search, Moon, Sun, Bell } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import { useEmployees } from '../../context/EmployeeContext';

const Navbar = () => {
  const { theme, toggleTheme } = useTheme();
  const { searchTerm, setSearchTerm } = useEmployees();

  return (
    <header className="sticky top-0 z-10 border-b dark:border-gray-700 bg-white dark:bg-gray-800 transition-colors duration-200">
      <div className="px-4 md:px-6 py-3 flex items-center justify-between">
        {/* Left side - Search */}
        <div className="relative flex-1 max-w-md">
          <div className="relative">
            <input
              type="text"
              placeholder="Search employees..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 w-full rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent transition-colors"
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400 dark:text-gray-500" />
          </div>
        </div>

        {/* Right side - Actions */}
        <div className="flex items-center ml-4 space-x-4">
          {/* Notifications */}
          <button className="p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
            <Bell className="h-5 w-5 text-gray-600 dark:text-gray-300" />
          </button>
          
          {/* Theme toggle */}
          <button 
            onClick={toggleTheme}
            className="p-1.5 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
            aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
          >
            {theme === 'dark' ? (
              <Sun className="h-5 w-5 text-gray-300" />
            ) : (
              <Moon className="h-5 w-5 text-gray-600" />
            )}
          </button>
          
          {/* Profile */}
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center text-white font-medium">
              HR
            </div>
            <span className="hidden md:inline text-sm font-medium text-gray-700 dark:text-gray-300">Admin</span>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navbar;