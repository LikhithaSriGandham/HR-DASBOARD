export interface Employee {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  age: number;
  gender: string;
  phone: string;
  image: string;
  address: {
    address: string;
    city: string;
    state: string;
    postalCode: string;
  };
  department: string;
  performanceRating: number;
  performanceHistory: PerformanceHistory[];
  projects: Project[];
  feedback: Feedback[];
}

export interface PerformanceHistory {
  date: string;
  rating: number;
  feedback: string;
}

export interface Project {
  name: string;
  role: string;
  status: string;
  completionPercentage: number;
}

export interface Feedback {
  reviewer: string;
  date: string;
  rating: number;
  comment: string;
}