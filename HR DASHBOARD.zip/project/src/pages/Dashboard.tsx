import React, { useEffect } from 'react';
import { useEmployees } from '../context/EmployeeContext';
import PageHeader from '../components/ui/PageHeader';
import EmployeeCard from '../components/ui/EmployeeCard';
import FilterDropdown from '../components/ui/FilterDropdown';
import EmptyState from '../components/ui/EmptyState';
import { UserSearch, Loader } from 'lucide-react';

const Dashboard = () => {
  const { 
    filteredEmployees, 
    loading, 
    error, 
    getDepartments 
  } = useEmployees();

  // Get unique departments for filter
  const departments = getDepartments();
  const departmentOptions = departments.map(dept => ({ label: dept, value: dept }));

  // Rating options for filter
  const ratingOptions = [
    { label: '5 Stars', value: 5 },
    { label: '4 Stars', value: 4 },
    { label: '3 Stars', value: 3 },
    { label: '2 Stars', value: 2 },
    { label: '1 Star', value: 1 },
  ];

  // Update document title
  useEffect(() => {
    document.title = 'HR Dashboard';
  }, []);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-64">
        <Loader className="h-12 w-12 text-indigo-500 animate-spin mb-4" />
        <p className="text-gray-600 dark:text-gray-400">Loading employee data...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-center">
        <div className="bg-red-100 dark:bg-red-900/30 p-4 rounded-full mb-4">
          <span className="text-red-600 dark:text-red-400 text-4xl">!</span>
        </div>
        <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">Error Loading Data</h2>
        <p className="text-gray-600 dark:text-gray-400 max-w-md">{error}</p>
        <button
          onClick={() => window.location.reload()}
          className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div>
      <PageHeader 
        title="Employee Dashboard" 
        description="View and manage your team's performance metrics"
      >
        <div className="flex flex-wrap gap-2">
          <FilterDropdown 
            type="department" 
            options={departmentOptions} 
            label="Department" 
          />
          <FilterDropdown 
            type="rating" 
            options={ratingOptions} 
            label="Rating" 
          />
        </div>
      </PageHeader>

      {filteredEmployees.length === 0 ? (
        <EmptyState
          title="No employees found"
          description="Try adjusting your search or filter criteria"
          icon={<UserSearch className="h-10 w-10 text-gray-400 dark:text-gray-500" />}
          action={
            <button
              onClick={() => window.location.reload()}
              className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
            >
              Reset Filters
            </button>
          }
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredEmployees.map(employee => (
            <EmployeeCard key={employee.id} employee={employee} />
          ))}
        </div>
      )}
    </div>
  );
};

export default Dashboard;