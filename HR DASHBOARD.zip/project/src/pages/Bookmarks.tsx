import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useBookmarks } from '../context/BookmarkContext';
import { useEmployees } from '../context/EmployeeContext';
import PageHeader from '../components/ui/PageHeader';
import EmployeeCard from '../components/ui/EmployeeCard';
import EmptyState from '../components/ui/EmptyState';
import BookmarkTrendsChart from '../components/analytics/BookmarkTrendsChart';
import { Bookmark, ArrowLeft } from 'lucide-react';

const Bookmarks = () => {
  const navigate = useNavigate();
  const { bookmarkedEmployees } = useBookmarks();
  const { employees } = useEmployees();
  
  // Filter employees to only show bookmarked ones
  const bookmarkedEmployeeList = employees.filter(
    employee => bookmarkedEmployees.includes(employee.id)
  );
  
  // Update document title
  useEffect(() => {
    document.title = 'Bookmarks | HR Dashboard';
    
    return () => {
      document.title = 'HR Dashboard';
    };
  }, []);
  
  return (
    <div>
      <PageHeader 
        title="Bookmarked Employees" 
        description="Manage your saved employee profiles"
      >
        <button
          onClick={() => navigate('/')}
          className="flex items-center px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 dark:bg-gray-800 dark:text-gray-200 dark:border-gray-600 dark:hover:bg-gray-700 transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Dashboard
        </button>
      </PageHeader>
      
      <div className="mb-8">
        <BookmarkTrendsChart bookmarkedCount={bookmarkedEmployees.length} />
      </div>
      
      {bookmarkedEmployeeList.length === 0 ? (
        <EmptyState
          title="No bookmarked employees"
          description="Employees you bookmark will appear here for quick access"
          icon={<Bookmark className="h-10 w-10 text-gray-400 dark:text-gray-500" />}
          action={
            <button
              onClick={() => navigate('/')}
              className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
            >
              Browse Employees
            </button>
          }
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {bookmarkedEmployeeList.map(employee => (
            <EmployeeCard key={employee.id} employee={employee} />
          ))}
        </div>
      )}
    </div>
  );
};

export default Bookmarks;