import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useEmployees } from '../context/EmployeeContext';
import { useBookmarks } from '../context/BookmarkContext';
import PageHeader from '../components/ui/PageHeader';
import PerformanceChart from '../components/analytics/PerformanceChart';
import BookmarkTrendsChart from '../components/analytics/BookmarkTrendsChart';
import { PieChart, ArrowLeft, Briefcase, Users, Award, LineChart } from 'lucide-react';

const Analytics = () => {
  const navigate = useNavigate();
  const { employees, getDepartments } = useEmployees();
  const { bookmarkedEmployees } = useBookmarks();
  
  // Calculate stats
  const totalEmployees = employees.length;
  const averagePerformance = employees.length 
    ? employees.reduce((sum, emp) => sum + emp.performanceRating, 0) / employees.length 
    : 0;
  const departments = getDepartments();
  
  // Update document title
  useEffect(() => {
    document.title = 'Analytics | HR Dashboard';
    
    return () => {
      document.title = 'HR Dashboard';
    };
  }, []);
  
  return (
    <div>
      <PageHeader 
        title="Performance Analytics" 
        description="Visualize employee performance metrics and trends"
      >
        <button
          onClick={() => navigate('/')}
          className="flex items-center px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 dark:bg-gray-800 dark:text-gray-200 dark:border-gray-600 dark:hover:bg-gray-700 transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Dashboard
        </button>
      </PageHeader>
      
      {/* Stats cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-5 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center">
            <div className="bg-blue-100 dark:bg-blue-900/30 p-3 rounded-full">
              <Users className="h-6 w-6 text-blue-600 dark:text-blue-400" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Total Employees</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{totalEmployees}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-5 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center">
            <div className="bg-purple-100 dark:bg-purple-900/30 p-3 rounded-full">
              <Briefcase className="h-6 w-6 text-purple-600 dark:text-purple-400" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Departments</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{departments.length}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-5 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center">
            <div className="bg-amber-100 dark:bg-amber-900/30 p-3 rounded-full">
              <Award className="h-6 w-6 text-amber-600 dark:text-amber-400" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Avg Performance</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{averagePerformance.toFixed(1)}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-5 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center">
            <div className="bg-green-100 dark:bg-green-900/30 p-3 rounded-full">
              <LineChart className="h-6 w-6 text-green-600 dark:text-green-400" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Bookmarked</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{bookmarkedEmployees.length}</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div>
          <PerformanceChart employees={employees} />
        </div>
        
        <div>
          <BookmarkTrendsChart bookmarkedCount={bookmarkedEmployees.length} />
        </div>
      </div>
      
      {/* Top Performers Section */}
      <div className="mt-8">
        <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Top Performers</h3>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden border border-gray-200 dark:border-gray-700">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
              <thead className="bg-gray-50 dark:bg-gray-700">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Employee
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Department
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Rating
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                {employees
                  .sort((a, b) => b.performanceRating - a.performanceRating)
                  .slice(0, 5)
                  .map(employee => (
                    <tr 
                      key={employee.id}
                      className="hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer transition-colors"
                      onClick={() => navigate(`/employee/${employee.id}`)}
                    >
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="h-10 w-10 flex-shrink-0">
                            <img 
                              className="h-10 w-10 rounded-full object-cover" 
                              src={employee.image} 
                              alt={`${employee.firstName} ${employee.lastName}`}
                            />
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900 dark:text-white">
                              {employee.firstName} {employee.lastName}
                            </div>
                            <div className="text-sm text-gray-500 dark:text-gray-400">
                              {employee.email}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getDepartmentColor(employee.department)}`}>
                          {employee.department}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="mr-2">
                            <RatingStars rating={employee.performanceRating} size="sm" />
                          </div>
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getRatingColor(employee.performanceRating)}`}>
                            {employee.performanceRating}
                          </span>
                        </div>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

// Helper function to get department color
const getDepartmentColor = (department: string) => {
  const colors: Record<string, string> = {
    'Engineering': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
    'Marketing': 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
    'HR': 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200',
    'Finance': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
    'Sales': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
    'Product': 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200',
    'Design': 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
  };

  return colors[department] || 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200';
};

// Helper function to get rating color
const getRatingColor = (rating: number) => {
  if (rating >= 4) {
    return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400';
  } else if (rating >= 3) {
    return 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400';
  } else if (rating >= 2) {
    return 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400';
  } else {
    return 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400';
  }
};

export default Analytics;