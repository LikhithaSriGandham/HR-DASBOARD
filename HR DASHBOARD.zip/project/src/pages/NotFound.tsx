import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Home, AlertCircle } from 'lucide-react';

const NotFound = () => {
  // Update document title
  useEffect(() => {
    document.title = 'Page Not Found | HR Dashboard';
    
    return () => {
      document.title = 'HR Dashboard';
    };
  }, []);

  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] text-center px-4">
      <div className="rounded-full bg-red-100 dark:bg-red-900/30 p-6 mb-6">
        <AlertCircle className="h-16 w-16 text-red-500 dark:text-red-400" />
      </div>
      
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Page Not Found</h1>
      
      <p className="text-gray-600 dark:text-gray-400 max-w-md mb-8">
        The page you're looking for doesn't exist or has been moved.
      </p>
      
      <Link 
        to="/"
        className="flex items-center px-5 py-2.5 bg-indigo-600 text-white font-medium rounded-md hover:bg-indigo-700 transition-colors focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 dark:focus:ring-offset-gray-800"
      >
        <Home className="w-4 h-4 mr-2" />
        Back to Dashboard
      </Link>
    </div>
  );
};

export default NotFound;