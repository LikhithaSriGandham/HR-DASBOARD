import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useEmployees } from '../context/EmployeeContext';
import { useBookmarks } from '../context/BookmarkContext';
import PageHeader from '../components/ui/PageHeader';
import RatingStars from '../components/ui/RatingStars';
import EmptyState from '../components/ui/EmptyState';
import { User, MapPin, Phone, Mail, Building, Award, Bookmark, BookmarkCheck, ArrowLeft, Calendar, BarChart3, FileText, MessageSquare, Briefcase as BriefcaseBusiness, Loader, UserX } from 'lucide-react';

const EmployeeDetails = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getEmployeeById } = useEmployees();
  const { isBookmarked, addBookmark, removeBookmark } = useBookmarks();
  
  const [activeTab, setActiveTab] = useState<'overview' | 'projects' | 'feedback'>('overview');
  
  const employee = id ? getEmployeeById(parseInt(id, 10)) : undefined;
  const bookmarked = id ? isBookmarked(parseInt(id, 10)) : false;
  
  const handleBack = () => {
    navigate(-1);
  };
  
  const handleBookmark = () => {
    if (id) {
      const employeeId = parseInt(id, 10);
      if (bookmarked) {
        removeBookmark(employeeId);
      } else {
        addBookmark(employeeId);
      }
    }
  };
  
  // Update document title
  useEffect(() => {
    if (employee) {
      document.title = `${employee.firstName} ${employee.lastName} | HR Dashboard`;
    } else {
      document.title = 'Employee Details | HR Dashboard';
    }
    
    return () => {
      document.title = 'HR Dashboard';
    };
  }, [employee]);
  
  if (!id || !employee) {
    return (
      <EmptyState
        title="Employee Not Found"
        description="The employee you're looking for doesn't exist or has been removed."
        icon={<UserX className="h-10 w-10 text-gray-400 dark:text-gray-500" />}
        action={
          <button
            onClick={handleBack}
            className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
          >
            Back to Dashboard
          </button>
        }
      />
    );
  }
  
  // Get performance rating color
  const getRatingColor = (rating: number) => {
    if (rating >= 4) {
      return 'text-green-600 bg-green-100 dark:text-green-400 dark:bg-green-900/30';
    } else if (rating >= 3) {
      return 'text-blue-600 bg-blue-100 dark:text-blue-400 dark:bg-blue-900/30';
    } else if (rating >= 2) {
      return 'text-amber-600 bg-amber-100 dark:text-amber-400 dark:bg-amber-900/30';
    } else {
      return 'text-red-600 bg-red-100 dark:text-red-400 dark:bg-red-900/30';
    }
  };

  // Get department color
  const getDepartmentColor = (department: string) => {
    const colors: Record<string, string> = {
      'Engineering': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
      'Marketing': 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
      'HR': 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200',
      'Finance': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
      'Sales': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
      'Product': 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-200',
      'Design': 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
    };

    return colors[department] || 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200';
  };
  
  // Get status color
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Completed':
        return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-200';
      case 'In Progress':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-200';
      case 'Planned':
        return 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-200';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200';
    }
  };
  
  // Render tabs
  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <div className="space-y-6">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 border border-gray-200 dark:border-gray-700">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4 flex items-center">
                <User className="mr-2 h-5 w-5 text-gray-500 dark:text-gray-400" />
                Personal Information
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <div className="flex items-start">
                    <Mail className="h-5 w-5 text-gray-500 dark:text-gray-400 mt-0.5 mr-2" />
                    <div>
                      <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Email Address</p>
                      <p className="text-gray-900 dark:text-white">{employee.email}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <Phone className="h-5 w-5 text-gray-500 dark:text-gray-400 mt-0.5 mr-2" />
                    <div>
                      <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Phone Number</p>
                      <p className="text-gray-900 dark:text-white">{employee.phone}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <Calendar className="h-5 w-5 text-gray-500 dark:text-gray-400 mt-0.5 mr-2" />
                    <div>
                      <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Age</p>
                      <p className="text-gray-900 dark:text-white">{employee.age} years</p>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-start">
                    <MapPin className="h-5 w-5 text-gray-500 dark:text-gray-400 mt-0.5 mr-2" />
                    <div>
                      <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Address</p>
                      <p className="text-gray-900 dark:text-white">
                        {employee.address.address}, {employee.address.city}, {employee.address.state} {employee.address.postalCode}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <Building className="h-5 w-5 text-gray-500 dark:text-gray-400 mt-0.5 mr-2" />
                    <div>
                      <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Department</p>
                      <div className="mt-1">
                        <span className={`text-xs font-medium px-2.5 py-0.5 rounded-full ${getDepartmentColor(employee.department)}`}>
                          {employee.department}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 border border-gray-200 dark:border-gray-700">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4 flex items-center">
                <BarChart3 className="mr-2 h-5 w-5 text-gray-500 dark:text-gray-400" />
                Performance History
              </h3>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Current Rating</p>
                  <div className="flex items-center">
                    <RatingStars rating={employee.performanceRating} size="lg" />
                    <span className={`ml-2 text-xs font-medium px-2.5 py-0.5 rounded-full ${getRatingColor(employee.performanceRating)}`}>
                      {employee.performanceRating}/5
                    </span>
                  </div>
                </div>
                
                <div className="divide-y divide-gray-200 dark:divide-gray-700">
                  {employee.performanceHistory.map((history, index) => (
                    <div key={index} className="py-4">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm font-medium text-gray-900 dark:text-white">{history.date}</span>
                        <RatingStars rating={history.rating} size="sm" />
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{history.feedback}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        );
        
      case 'projects':
        return (
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 border border-gray-200 dark:border-gray-700">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4 flex items-center">
              <BriefcaseBusiness className="mr-2 h-5 w-5 text-gray-500 dark:text-gray-400" />
              Project Assignments
            </h3>
            
            {employee.projects.length === 0 ? (
              <p className="text-gray-600 dark:text-gray-400">No projects assigned yet.</p>
            ) : (
              <div className="space-y-6">
                {employee.projects.map((project, index) => (
                  <div 
                    key={index} 
                    className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4 border border-gray-200 dark:border-gray-700"
                  >
                    <div className="flex flex-wrap items-start justify-between mb-2">
                      <h4 className="text-base font-medium text-gray-900 dark:text-white">{project.name}</h4>
                      <span className={`text-xs font-medium px-2.5 py-0.5 rounded-full ${getStatusColor(project.status)}`}>
                        {project.status}
                      </span>
                    </div>
                    
                    <div className="mb-4">
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        Role: <span className="font-medium text-gray-800 dark:text-gray-200">{project.role}</span>
                      </p>
                    </div>
                    
                    <div>
                      <div className="flex justify-between mb-1 text-xs font-medium">
                        <span className="text-gray-700 dark:text-gray-300">Completion</span>
                        <span className="text-gray-700 dark:text-gray-300">{project.completionPercentage}%</span>
                      </div>
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                        <div 
                          className="bg-blue-500 h-2 rounded-full" 
                          style={{ width: `${project.completionPercentage}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
        
      case 'feedback':
        return (
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 border border-gray-200 dark:border-gray-700">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4 flex items-center">
              <MessageSquare className="mr-2 h-5 w-5 text-gray-500 dark:text-gray-400" />
              Feedback & Reviews
            </h3>
            
            <div className="space-y-6">
              {employee.feedback.map((item, index) => (
                <div 
                  key={index} 
                  className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4 border border-gray-200 dark:border-gray-700"
                >
                  <div className="flex flex-wrap items-start justify-between mb-3">
                    <div>
                      <h4 className="text-base font-medium text-gray-900 dark:text-white">
                        {item.reviewer}
                      </h4>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        Reviewed on {item.date}
                      </p>
                    </div>
                    <RatingStars rating={item.rating} size="sm" />
                  </div>
                  
                  <blockquote className="text-sm text-gray-600 dark:text-gray-400 italic">
                    "{item.comment}"
                  </blockquote>
                </div>
              ))}
              
              <div className="mt-6">
                <button
                  className="w-full py-2.5 px-4 rounded-lg border border-indigo-600 text-indigo-600 font-medium hover:bg-indigo-50 dark:border-indigo-400 dark:text-indigo-400 dark:hover:bg-indigo-900/20 transition-colors"
                >
                  Add New Feedback
                </button>
              </div>
            </div>
          </div>
        );
        
      default:
        return null;
    }
  };
  
  return (
    <div>
      <PageHeader
        title={`${employee.firstName} ${employee.lastName}`}
        description={`${employee.department} • ID: ${employee.id}`}
      >
        <div className="flex space-x-3">
          <button
            onClick={handleBack}
            className="flex items-center px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 dark:bg-gray-800 dark:text-gray-200 dark:border-gray-600 dark:hover:bg-gray-700 transition-colors"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </button>
          
          <button
            onClick={handleBookmark}
            className={`flex items-center px-4 py-2 rounded-md shadow-sm transition-colors ${
              bookmarked 
                ? 'bg-amber-100 text-amber-700 border border-amber-200 hover:bg-amber-200 dark:bg-amber-900/20 dark:text-amber-400 dark:border-amber-800 dark:hover:bg-amber-900/30' 
                : 'text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 dark:bg-gray-800 dark:text-gray-200 dark:border-gray-600 dark:hover:bg-gray-700'
            }`}
          >
            {bookmarked ? (
              <>
                <BookmarkCheck className="w-4 h-4 mr-2" />
                Bookmarked
              </>
            ) : (
              <>
                <Bookmark className="w-4 h-4 mr-2" />
                Bookmark
              </>
            )}
          </button>
        </div>
      </PageHeader>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Employee Profile Card */}
        <div className="lg:col-span-1">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden border border-gray-200 dark:border-gray-700">
            <div className="p-6">
              <div className="flex flex-col items-center text-center">
                <img 
                  src={employee.image} 
                  alt={`${employee.firstName} ${employee.lastName}`}
                  className="w-24 h-24 rounded-full object-cover mb-4 border-2 border-gray-200 dark:border-gray-700"
                />
                
                <h2 className="text-xl font-bold text-gray-900 dark:text-white">
                  {employee.firstName} {employee.lastName}
                </h2>
                
                <p className="text-gray-600 dark:text-gray-400 mb-2">{employee.email}</p>
                
                <div className="flex items-center mb-4">
                  <span className={`text-xs font-medium px-2.5 py-0.5 rounded-full ${getDepartmentColor(employee.department)}`}>
                    {employee.department}
                  </span>
                </div>
                
                <div className="flex flex-col items-center">
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Performance Rating</p>
                  <div className="flex items-center">
                    <RatingStars rating={employee.performanceRating} />
                    <span className={`ml-2 text-xs font-medium px-2.5 py-0.5 rounded-full ${getRatingColor(employee.performanceRating)}`}>
                      {employee.performanceRating}/5
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">Gender</p>
                    <p className="font-medium text-gray-900 dark:text-white capitalize">{employee.gender}</p>
                  </div>
                  
                  <div className="text-right">
                    <p className="text-sm text-gray-500 dark:text-gray-400">Location</p>
                    <p className="font-medium text-gray-900 dark:text-white">{employee.address.city}</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="px-6 py-4 bg-gray-50 dark:bg-gray-700/50 border-t border-gray-200 dark:border-gray-700">
              <button
                className="w-full py-2 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-md transition-colors focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 dark:focus:ring-offset-gray-800"
                onClick={handlePromote}
              >
                <Award className="inline-block w-4 h-4 mr-2" />
                Recommend for Promotion
              </button>
            </div>
          </div>
        </div>
        
        {/* Tabs and Content */}
        <div className="lg:col-span-2">
          {/* Tabs */}
          <div className="mb-4 border-b border-gray-200 dark:border-gray-700">
            <ul className="flex flex-wrap -mb-px">
              <li className="mr-2">
                <button
                  className={`inline-flex items-center py-4 px-4 text-sm font-medium border-b-2 rounded-t-lg ${
                    activeTab === 'overview'
                      ? 'text-indigo-600 border-indigo-600 dark:text-indigo-400 dark:border-indigo-400'
                      : 'text-gray-500 border-transparent hover:text-gray-600 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
                  }`}
                  onClick={() => setActiveTab('overview')}
                >
                  <FileText className="mr-2 w-4 h-4" />
                  Overview
                </button>
              </li>
              <li className="mr-2">
                <button
                  className={`inline-flex items-center py-4 px-4 text-sm font-medium border-b-2 rounded-t-lg ${
                    activeTab === 'projects'
                      ? 'text-indigo-600 border-indigo-600 dark:text-indigo-400 dark:border-indigo-400'
                      : 'text-gray-500 border-transparent hover:text-gray-600 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
                  }`}
                  onClick={() => setActiveTab('projects')}
                >
                  <BriefcaseBusiness className="mr-2 w-4 h-4" />
                  Projects
                </button>
              </li>
              <li>
                <button
                  className={`inline-flex items-center py-4 px-4 text-sm font-medium border-b-2 rounded-t-lg ${
                    activeTab === 'feedback'
                      ? 'text-indigo-600 border-indigo-600 dark:text-indigo-400 dark:border-indigo-400'
                      : 'text-gray-500 border-transparent hover:text-gray-600 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
                  }`}
                  onClick={() => setActiveTab('feedback')}
                >
                  <MessageSquare className="mr-2 w-4 h-4" />
                  Feedback
                </button>
              </li>
            </ul>
          </div>
          
          {/* Tab Content */}
          <div className="mt-4">
            {renderTabContent()}
          </div>
        </div>
      </div>
    </div>
  );
};

// Add a function to handle promote action
const handlePromote = (e: React.MouseEvent) => {
  e.stopPropagation();
  alert('Recommendation for promotion has been submitted!');
};

export default EmployeeDetails;